# ScanPoint

Scan POI's around the world!

## Start the App
First, get the dependencies
```bash
flutter pub get
```
Then, start the application
```bash
flutter run
```
